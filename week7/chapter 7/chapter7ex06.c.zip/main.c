/*****************************************************************
 * Write a program that takes a series of numbers and counts the
 *number of positive and negative values.
 *****************************************************************/

#include <stdio.h>

char line[100];

float valor;
int positivos;
int negativos;


int main(void) {

  while (1) {

    printf("ingrese el siguiente numero de su sucesion. ingrese 0 para terminar el proceso: ");
    fgets(line, sizeof(line), stdin);
    sscanf(line, "%f", &valor);

    if (valor == 0.0 ) {
      
      printf("hay %d numeros positivos y %d numeros negativos", positivos, negativos);
      
      return 0;
    }
    if (valor < 0.0 ) {

      negativos += 1;
    }

    if (valor > 0.0 ) {

      positivos += 1;
    }

  }

}
 

