/*********************************************************************
 * Write a program to add an 8% sales tax to a given amount and round
 * the result to the nearest penny.
 *********************************************************************/

#include <stdio.h>
#undef DEBUG

char line[100];

float Gasto;
float impuesto;
float Gasto_total;

int peso;
int centavos;

int main(void) {

/*obtiene el gasto inicial*/

printf("ingrese la cantidad gastada: ");
fgets(line, sizeof(line), stdin);
sscanf(line, "%f", &Gasto);

#ifdef DEBUG
  printf("DEBUG:main(): gasto es %f", Gasto);
#endif

/*para obtener el impuesto del 8% sobre la cantidad gastada*/

impuesto = Gasto * .08;

#ifdef DEBUG
  printf("DEBUG:main(): impuesto es %f", impuesto);
#endif

/*calculando el gasto + el impuesto */

Gasto_total = impuesto +  Gasto;

#ifdef DEBUG
  printf("DEBUG:main(): Gasto_total es %f", Gasto_total);
#endif

printf("la cantidad gastada es de %0.2f\n", Gasto_total);

  return 0;
}