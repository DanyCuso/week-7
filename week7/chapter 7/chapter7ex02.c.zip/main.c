#include <stdio.h>
#include <math.h>

int main(void) {

float total_days;

float d_year;
float d_month;
float d_days;

float f_year, f_month, f_day;
float l_year, l_month, l_day;

  f_year = 1090 * 365;
  f_month = 6 * 12;
  f_day = 6;

  l_year = 1092 * 365;
  l_month = 3 * 12;
  l_day = 4;

  d_year = (l_year - f_year);
  d_month = (l_month - f_month);
  d_days = (l_day - f_day);

  total_days = d_days + d_month + d_year;

printf("hay un total de %f dias entre 6/6/90 y 4/3/92", total_days);

  return 0;
}