#include <stdio.h>

const float milla_kilometro  = 1.6093;
const float Galon_litro    = 3.7854;
const float pulgada_centimetro = 2.54;
const float pie_metro      = 0.3048;

char line[100];             
char tipo_unidad;             
float valor_unidad;           
float resultado;               

int main() {
	while (1) {

		
		tipo_unidad = '\0';
		valor_unidad = 0.0;

		
		printf("\n(m:millas g:galones i:pulgadas f:pies q:salir)\n");
		printf("ingrese el tipo de unidad y su valor en ese orden: \n");
    printf("ingrese q para terminar el programa \n");
		fgets(line, sizeof(line), stdin);
		sscanf(line, "%c %f", &tipo_unidad, &valor_unidad);

		
		if ((tipo_unidad == 'q') || (tipo_unidad == 'Q')) {
			printf("adios!\n");
			return(0);
		}

		
		if (tipo_unidad == 'm') {
			resultado = valor_unidad * milla_kilometro;
			printf("%f millas = %f kilometros\n", valor_unidad, resultado);
		} else if (tipo_unidad == 'g') {
			resultado = valor_unidad * Galon_litro;
			printf("%f galones = %f litros\n", valor_unidad, resultado);
		} else if (tipo_unidad == 'i') {
			resultado = valor_unidad * pulgada_centimetro;
			printf("%f pulgadas = %f centimetros\n", valor_unidad, resultado);
		} else if (tipo_unidad == 'f') {
			resultado = valor_unidad * pie_metro;
			printf("%f pies = %f metros\n", valor_unidad, resultado);
		} else {
			printf("Error: conversion desconocida\n");
			continue;
		}
	}
}