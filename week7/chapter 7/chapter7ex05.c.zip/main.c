/*************************************************
 * Write a program to tell if a number is prime.
 *************************************************/

#include <stdio.h>
#undef DEBUG

char line[100];

int number_value;
int number_reference = 0;
int number_count ;


int main(void) {

printf("ingrese el numero que desea comprobar: ");
fgets(line, sizeof(line), stdin);
sscanf(line, "%d", &number_value);

#ifdef DEBUG
  printf("DEBUG:main(): number_value es %d", numeber_value);
#endif

 for (number_count = 2; number_count <= number_value / 2; ++number_count) {
    // condition for non-prime
    if (number_value % number_count == 0) {
      number_reference = 1;
      break;
    }
  }

  if (number_value == 1) {
    printf("1 no es un numero posible de ejecutar.");
  } 
  else {
    if (number_reference == 0)
      printf("%d es numero primo.", number_value);
    else
      printf("%d no es numero primo.", number_value);
  }

  return 0;
}




