/**********************************************************************
 * A serial transmission line can transmit 960 characters each second.
 * Write a program that will calculate the time required to send a file,
 * given the file's size. Try the program on a 400MB (419,430,400 byte)
 * file. Use appropriate units. (A 400MB file takes days.)
 **********************************************************************/


#include <stdio.h>
#undef DEBUG




char line[100];

const int CPS = 960;                     /*Bytes por segundo*/

const int MINUTO = 60;
const int HORA = 60 * 60;
const int DIA = 60 * 60 * 24;

int SEGUNDOS;

int tamaño_MB;               /*establece el tamaño en MegaBytes*/
int tamaño_B;                /*establece el tamaño en Bytes*/

int segundos, minutos, horas, dias;

int main(void) {

  printf("ingrese el tamaño del archivo en MB: ");
  fgets(line, sizeof(line), stdin);
  sscanf(line, "%d", &tamaño_MB);

  tamaño_B = tamaño_MB * 1048576;

#ifdef DEBUG
    printf("DEBUG:main(): tamaño_B es %d\n", tamaño_B);
#endif

SEGUNDOS = tamaño_B / CPS;           /*1 caracter = 1 byte*/

#ifdef DEBUG
  printf("DEBUG:main(): SEGUNDOS es %d\n", SEGUNDOS);
#endif

dias = SEGUNDOS / DIA;
SEGUNDOS = SEGUNDOS % DIA;

#ifdef DEBUG
  printf("DEBUG:main(): dias es %d\n", dias);
  printf("DEBUG:main(): R_SEGUNDOS es %d\n", SEGUNDOS);
#endif

horas = SEGUNDOS / HORA;
SEGUNDOS = SEGUNDOS % HORA;

#ifdef DEBUG
  printf("DEBUG:main(): horas es %d\n", horas);
  printf("DEBUG:main(): R_SEGUNDOS es %d\n", SEGUNDOS);
#endif

minutos = SEGUNDOS / MINUTO;
segundos = SEGUNDOS % MINUTO;

#ifdef DEBUG 
  printf("DEBUG:main(): minutos es %d\n", minutos);
  printf("DEBUG:mian(): segundos es %d\n", segundos);
#endif

  printf("%d dias, %d horas, %d minutos, %d segundos", dias, horas, minutos, segundos);

  return 0;
}