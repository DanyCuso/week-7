#include <stdio.h>

char line[100];             
int año;                  
int año_bisiesto = 0;          

int main() {
	printf("ingresa un año: ");
	fgets(line, sizeof(line), stdin);
	sscanf(line, "%d", &año);

	
	if (año % 4 == 0) {
	año_bisiesto = 1;

		
		if (año % 100 == 0) {
			if (año % 400 != 0) {
				año_bisiesto = 0;
			}
		}

	}

	if (año_bisiesto == 1) {
		printf("%d es un año bisiesto.\n", año);
	} else {
		printf("%d no es un año bisiesto.\n", año);
	}

	return(0);
}