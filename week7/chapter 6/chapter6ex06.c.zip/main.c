#include <stdio.h>

char line[100];             
float horas;                
float sueldo;                 
float horas_Extra = 0.0;       
float pago;             

int main() {
	printf("ingrese sus horas trabajadas: ");
	fgets(line, sizeof(line), stdin);
	sscanf(line, "%f", &horas);

	printf("ingrese su sueldo por hora: ");
	fgets(line, sizeof(line), stdin);
	sscanf(line, "%f", &sueldo);

	if (horas> 40.0) {
		horas_Extra = (horas - 40.0) * 1.5;
		horas = 40.0;
		pago = (horas * sueldo) + (horas_Extra * sueldo);
	} else {
		pago = horas * sueldo;
	}

	printf("su pago es de: $%0.2f\n", pago);

	return(0);
}