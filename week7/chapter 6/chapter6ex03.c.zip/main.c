#include <stdio.h>

int porcentaje;      
char calificacion;             
char modificador;          
char line[100];         

int main() {
	printf("ingrese porcentaje: ");
	fgets(line, sizeof(line), stdin);
	sscanf(line, "%d", &porcentaje);

	modificador = ' ';   

	if (porcentaje > 100) {
		printf("fuera de limite\n");
		return(1);
	} else if (porcentaje < 0) {
		printf("fuera de limite\n");
		return(1);
	} else if (porcentaje >= 91) {
		calificacion = 'A';
		if (porcentaje >= 98) {
			modificador = '+';
		} else if (porcentaje <= 93) {
			modificador = '-';
		}
	} else if (porcentaje >= 81) {
		calificacion = 'B';
		if (porcentaje >= 88) {
			modificador = '+';
		} else if (porcentaje <= 83) {
			modificador = '-';
		}
	} else if (porcentaje >= 71) {
		calificacion = 'C';
		if (porcentaje >= 78) {
			modificador = '+';
		} else if (porcentaje <= 73) {
			modificador = '-';
		}
	} else if (porcentaje >= 61) {
		calificacion = 'D';
		if (porcentaje >= 68) {
			modificador = '+';
		} else if (porcentaje <= 63) {
			modificador = '-';
		}
	} else {
		calificacion = 'F';
	}

	printf("la calificacion es %c%c\n", calificacion, modificador);

	return(0);
}

