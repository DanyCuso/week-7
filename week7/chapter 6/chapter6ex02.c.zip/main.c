#include <stdio.h>

float correcto;    
char calificacion;             
char line[100];         

int main() {
	printf("incerte porcentaje: ");
	fgets(line, sizeof(line), stdin);
	sscanf(line, "%f", &correcto);

	if (correcto >= 91.0) {
		calificacion = 'A';
	} else if (correcto >= 81.0) {
		calificacion = 'B';
	} else if (correcto >= 71.0) {
		calificacion = 'C';
	} else if (correcto >= 61.0) {
		calificacion = 'D';
	} else {
		calificacion = 'F';
	}

	printf("la calificacion es %c\n", calificacion);

	return(0);
}

