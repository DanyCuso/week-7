
#include <stdio.h>
#include <math.h>

char line[100];            
float distancia;             
float cuadrado;               
float raiz_cuadrada;          

int main() {
	
  printf("escriba la distancia: ");
	fgets(line, sizeof(line), stdin);
	sscanf(line, "%f", &distancia);

	cuadrado = distancia * distancia;
	printf("el cuadrado de la distancia es %f\n", cuadrado);

	raiz_cuadrada = sqrtf(cuadrado);
	printf("la raiz del resultado anterior es %f\n", raiz_cuadrada);

	return(0);
}

