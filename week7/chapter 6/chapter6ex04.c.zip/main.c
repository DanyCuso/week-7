#include <stdio.h>

char line[100];             
int centavos;                 
int cuartos = 0;           
int decimos = 0;              
int quintimos = 0;            
int centimos = 0;            

int main() {
	printf("ingresa el numero de centavos que tienes: ");
	fgets(line, sizeof(line), stdin);
	sscanf(line, "%d", &centavos);

	if (centavos > 99) {
		printf("Error: tienes 1:00$ o mas\n");
		return(1);
	} else if (centavos < 1) {
		printf("Error: no puedes tener menos de un centimo\n");
		return(1);
	}

	while (1) {
		if (centavos >= 25) {
			++cuartos;
			centavos -= 25;
		} else if (centavos >= 10) {
			++decimos;
			centavos -= 10;
		} else if (centavos >= 5) {
			++quintimos;
			centavos -= 5;
		} else if (centavos >= 1) {
			++centimos;
			--centavos;
		} else if (centavos == 0) {
			break;
		}
	}

	printf("%d cuartos %d decimos %d quintimos %d centimos\n",
		cuartos, decimos, quintimos, centimos);

	return(0);
}