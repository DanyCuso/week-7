/*********************************************************************
 *Exercise 8-2
 *
 * The total resistance of n resistors in parallel is:
 * 1/R = 1/R1 + 1/R2 + 1/R3 + ... + 1/Rn
 * Suppose we have a network of two resistors with the values 400 ohms  * and 200
 * ohms. Then our equation would be:
 * 1/R = 1/R1 + 1/R2
 * Substituting in the value of our resistors we get:
 * 1/R = 1/400 + 1/200
 * 1/R = 3/400
 * R = 400/3
 * So the total resistance of our two-resistor network is 133.3 ohms.
 * Write a program to compute the total resistance for any number of   * parallel
 * resistors.
 *********************************************************************/

#include <stdio.h>

char line[100];

float resistencia;
float total;

int main(void) {

while (1) {
	
		printf("introdusca el valor de la resistencia en ohms: ");
		fgets(line, sizeof(line), stdin);
		sscanf(line, "%f", &resistencia);

		if (resistencia == 0.0) {
			printf("el valor total de la resistencia es: %0.04f\n", 1.0 / total);
			return(0);
		}

		total += 1.0 / resistencia;

	}
}


