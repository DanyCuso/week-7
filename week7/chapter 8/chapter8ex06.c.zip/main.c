/*********************************************************************
 * Write a program that converts numbers to words. For example, 895
 *results in "eight nine five."
 *********************************************************************/

#include <stdio.h>
#include <string.h>
char line[100];

int number;
int i;
char word[100];

int main(void) {

printf("ingresa un numero: ");
fgets(line, sizeof(line), stdin);

  for (i = 0; ;i++ ) {
      if (line[i] == '\n') {

        printf("\n");
        return 0;
      }
  switch (line[i]) {

    case '0':
				strcpy(word, "cero");
				break;
			case '1':
				strcpy(word, "uno");
				break;
			case '2':
				strcpy(word, "dos");
				break;
			case '3':
				strcpy(word, "tres");
				break;
			case '4':
				strcpy(word, "cuatro");
				break;
			case '5':
				strcpy(word, "cinco");
				break;
			case '6':
				strcpy(word, "seis");
				break;
			case '7':
				strcpy(word, "siete");
				break;
			case '8':
				strcpy(word, "ocho");
				break;
			case '9':
				strcpy(word, "nueve");
				break;
			default:
				strcpy(word, "desconocido");
				break;
		}
		printf("%s ", word);
	}
}


