/**********************************************************************
 * The number 85 is pronounced "eighty-five," not "eight five." Modify
 * the previous program to handle the numbers through 100 so that all * * numbers come
 * out as we really say them. For example, 13 would be "thirteen" and * * 100 would be
 * "one hundred."
 *********************************************************************/

#include <stdio.h>
#include <string.h>

int number;                 

int decenas;             
int Udigito;             

int main() {

	for (number = 0; number <= 100; ++number) {

		
		if (number < 20) {
			switch (number) {
				case 0:
					printf("zero");
					break;
				case 1:
					printf("uno");
					break;
				case 2:
					printf("dos");
					break;
				case 3:
					printf("tres");
					break;
				case 4:
					printf("cuatro");
					break;
				case 5:
					printf("cinco");
					break;
				case 6:
					printf("seis");
					break;
				case 7:
					printf("siete");
					break;
				case 8:
					printf("ocho");
					break;
				case 9:
					printf("nueve");
					break;
				case 10:
					printf("diez");
					break;
				case 11:
					printf("once");
					break;
				case 12:
					printf("doce");
					break;
				case 13:
					printf("trece");
					break;
				case 14:
					printf("catorce");
					break;
				case 15:
					printf("quince");
					break;
				case 16:
					printf("dieciseis");
					break;
				case 17:
					printf("diecisiete");
					break;
				case 18:
					printf("dieciocho");
					break;
				case 19:
					printf("diecinueve");
					break;
			}

		} else if (number == 100) {
			printf("cien");

		} else {
			decenas = number / 10;       
			Udigito = number % 10;       

			switch (decenas) {
				case 2:
					printf("veinte");
					break;
				case 3:
					printf("treinta");
					break;
				case 4:
					printf("cuarenta");
					break;
				case 5:
					printf("cincuenta");
					break;
				case 6:
					printf("secenta");
					break;
				case 7:
					printf("setenta");
					break;
				case 8:
					printf("ochenta");
					break;
				case 9:
					printf("novanta");
					break;
			}

			switch (Udigito) {
				case 1:
					printf("-uno");
					break;
				case 2:
					printf("-dos");
					break;
				case 3:
					printf("-tres");
					break;
				case 4:
					printf("-cuatro");
					break;
				case 5:
					printf("-cinco");
					break;
				case 6:
					printf("-seis");
					break;
				case 7:
					printf("-siete");
					break;
				case 8:
					printf("-ocho");
					break;
				case 9:
					printf("-nueve");
					break;
			}
		}

		printf("\n");
	}

	return(0);
}