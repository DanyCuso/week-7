/**********************************************************
 *  Write a program to print out the multiplication table.
 **********************************************************/

 /*para las tablas basica: 1 a 10*/

#include <stdio.h>

char line[100];

int tabla;
int multiplicando;
int resultado;

int main(void) {

printf("cual tabal de multiplicar deseas conocer: \n");
fgets(line, sizeof(line), stdin);
sscanf(line, "%d", &tabla);

  while (1) {

      if (multiplicando > 9 ) {
      break;
      return 0;
      }

  multiplicando += 1;
  resultado = tabla * multiplicando;

  printf("%d * %d = %d\n",multiplicando, tabla, resultado);


  }
}