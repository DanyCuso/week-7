/*****************************************
 * Write a program to average n numbers.
 *****************************************/

#include <stdio.h>

char line[100];

float number_sum;
float number;
float promedio;
int total_num;

int main(void) {

  while (1) {

    printf("escribe el siguiente numero a promediar. inserta 0 para terminar el proceso: ");
    fgets(line, sizeof(line), stdin);
    sscanf(line, "%f", &number);

      if ( number == 0.0 ) {
        
        printf("el promedio es %0.2f", promedio);

        return 0;
      }

    total_num += 1;
    number_sum += 0 + number;
    promedio = number_sum / total_num; 

  }


}
