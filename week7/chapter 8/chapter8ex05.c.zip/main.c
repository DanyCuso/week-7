/**********************************************************************
 *Write a program that reads a character and prints out whether or not
 *it is a vowel or a consonant.
 **********************************************************************/

#include <stdio.h>

char line[100];                 
char caracter;                 

int main() {

	while (1) {
		printf("por una letra(0 si queires salir): ");
		fgets(line, sizeof(line), stdin);
		sscanf(line, "%c", &caracter);

		switch (caracter) {
			case 'a':
			case 'A':
			case 'e':
			case 'E':
			case 'i':
			case 'I':
			case 'o':
			case 'O':
			case 'u':
			case 'U':
				printf("es una vocal.\n");
				break;

			case 'b':
			case 'B':
			case 'c':
			case 'C':
			case 'd':
			case 'D':
			case 'f':
			case 'F':
			case 'g':
			case 'G':
			case 'h':
			case 'H':
			case 'j':
			case 'J':
			case 'k':
			case 'K':
			case 'l':
			case 'L':
			case 'm':
			case 'M':
			case 'n':
			case 'N':
			case 'p':
			case 'P':
			case 'q':
			case 'Q':
			case 'r':
			case 'R':
			case 's':
			case 'S':
			case 't':
			case 'T':
			case 'v':
			case 'V':
			case 'w':
			case 'W':
			case 'x':
			case 'X':
			case 'z':
			case 'Z':
				printf("es una consonante.\n");
				break;

			case 'y':
			case 'Y':
				printf("es una consonante en el español.\n");
				break;

			case '0':
				printf("hasta pronto.\n");
				return(0);

			default:
				printf("intenta con una letra mejor\nutiliza 0 para cerrar");
				break;

		}
	}

}