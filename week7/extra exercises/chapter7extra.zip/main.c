/**********************************************************************
 *             Calculadora de multiplicaciones generales
 **********************************************************************/

#include <stdio.h>
#undef DEBUG

char line[100];

int multiplicado;
int tabla = 1;
int resultado;

int main(void) {

  while (1) {

    printf("introdusca la tabla en la que desea multiplicar: ");
    fgets(line, sizeof(line), stdin);
    sscanf(line, "%d", &tabla);

    printf("ingrese el numero por el que desea multiplicar: ");
    fgets(line, sizeof(line), stdin);
    sscanf(line, "%d", &multiplicado);

    if (multiplicado == 0) {

      printf("HASTA PRONTO! :)");
      return 0;
    }

    resultado = multiplicado * tabla;
  
    printf("%d * %d = %d\n", multiplicado, tabla, resultado);
  }


}