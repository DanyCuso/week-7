/*********************************************************************
 *           calculadora de operaciones generales
 *********************************************************************/

#include <stdio.h>
#include <math.h>

char line[100];

float F_valor;
char operador;
float S_valor;
float resultado;

int main(void) {

  while (1) {

      printf("ingresa el numero que deseas calcular or (type 0 para salir) :  ");
      fgets(line, sizeof(line), stdin);
      sscanf(line, "%f", &F_valor);
        
        if (F_valor == 0 ){
             printf("HASTA LA PROXIMA! :D\n");
              return 0;
        }

      printf("ingresa el valor por el cual quieres calcular: ");
      fgets(line, sizeof(line), stdin);
      sscanf(line, "%f", &S_valor);
      
      printf("infgresa el tipo de operacion que deseas hacer \n(type '+','-', '*', '/') :  ");
      fgets(line, sizeof(line), stdin);
      sscanf(line, "%c", &operador);

      
      
        switch (operador) {

          case '+':
            resultado = F_valor + S_valor;
            printf("%0.2f + %f = %0.2f\n", F_valor, S_valor, resultado);
            break;
          
          case '-':
            resultado = F_valor - S_valor;
            printf("%0.2f - %f = %0.2f\n", F_valor, S_valor, resultado);
            break;
          
          case '*':
            resultado = F_valor * S_valor;
            printf("%0.2f * %0.2f = %0.2f\n", F_valor, S_valor, resultado);
            break;
          
          case '/': 
            resultado = F_valor / S_valor;
              if (S_valor == 0 ) {
                printf("Error: no puedes divir entre 0");
                return 0;
              }
            printf("%0.2f / %0.2f = %0.2f\n", F_valor, S_valor, resultado);
            break;
        }


  }

  

}